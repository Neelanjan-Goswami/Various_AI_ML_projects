# SanjulaMathur-Amazon-Selenium-Automation
Automated Amazon through Selenium in Python, which logins user automatically and adds few items to the cart and takes the user to the payment gateway.
